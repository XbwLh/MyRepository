package com.lxyk.utils;

import com.lxyk.pojo.Book;

import java.io.*;
import java.util.*;

/**
 * @ClassName BookUtil
 * @Description TODO
 * @Author FJQ
 * @Date 2022-02-24 20:09
 * @Version 1.0
 **/
public class BookUtil {
    //定义List集合    全局List  我们针对于图书的  增删改查都会在这个list进行
    private static List<Book> list;


    static {
        List<Book> bookList = new ArrayList<>();
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader("book.txt"));
            String line;
            while ((line = br.readLine()) != null) {
                String[] split = line.split(" ");
                Book book = new Book(Integer.parseInt(split[0]), split[1], split[2], Double.valueOf(split[3]),split[4],Integer.parseInt(split[5]));
                bookList.add(book);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if (br != null){
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        list = bookList;
    }

    public static List<Book> getList(){
        return list;
    }

    //根据书名判断该图书是否存在
    public static Book isExist(String name) {
        //创建Book对象
        Book book = new Book();       //此时的book对象是空的
        for (Book b : list) {
            if (b.getName().equals("《" + name + "》")) {
                //将系统中的图书对象给book对象
                book = b;
                return book;
            }
        }
        return null;
    }

    //整理书籍
    public static void sort() {
        TreeSet set = new TreeSet((o1, o2) ->{
            //按照价格从小到大排序
            if (o1 instanceof Book && o2 instanceof Book){
                Book book1 = (Book)o1;
                Book book2 = (Book)o2;
                int price = Double.compare(book1.getPrice(), book2.getPrice());
                int name = book1.getName().compareTo(book2.getName());
                return price == 0 ? name : price;

            }else {
                throw new RuntimeException("输入类型不匹配");
            }
        });

        for (int i = 0; i < list.size(); i++) {
            set.add(list.get(i));
        }

        //调用排序之后的查询
        show(set);

    }
    //排序之后的查询
    public static void show(Set set){
        System.out.println(" 图书名称 " + " 图书作者 " + " 图书价格  " + " 图书库存 ");
        Iterator<Book> iterator = set.iterator();
        while (iterator.hasNext()){
            Book book = iterator.next();
            System.out.println(book.getName() + "  " + book.getAuthor() + "  " + book.getPrice()+ " " + book.getCount());
        }
    }


    //io流最终写入到文本文件
    public static void mapIO(){
        Map<Integer,Book> map = new HashMap<>();

        TreeSet set = new TreeSet((o1, o2) ->{
            //按照价格从小到大排序
            if (o1 instanceof Book && o2 instanceof Book){
                Book book1 = (Book)o1;
                Book book2 = (Book)o2;
                return Integer.compare(book1.getId(),book2.getId());
            }else {
                throw new RuntimeException("输入类型不匹配");
            }
        });

        List<Book> bookList = getList();

        for (int i = 0; i < bookList.size(); i++) {
            set.add(bookList.get(i));
        }


        Iterator<Book> iterator = set.iterator();
        while (iterator.hasNext()){
            Book book = iterator.next();
            map.put(book.getId(),book);
        }

        BufferedWriter bw = null;
        try {
            bw = new BufferedWriter(new FileWriter("book.txt"));
            for (Map.Entry<Integer, Book> entry : map.entrySet()) {
                Book value = entry.getValue();
                bw.write(value.toString(value));
                bw.newLine();  //提供换行操作
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (bw != null){
                try {
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    //获得最大编号
    public static int getMaxId(List<Book> bookList){
        return bookList.stream().mapToInt(Book::getId).max().getAsInt();
    }



}