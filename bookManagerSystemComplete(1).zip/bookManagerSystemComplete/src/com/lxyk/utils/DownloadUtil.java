package com.lxyk.utils;

import com.lxyk.pojo.Book;

import java.io.*;

/**
 * @ClassName DownloadUtil
 * @Description TODO
 * @Author FJQ
 * @Date 2022-02-19 20:41
 * @Version 1.0
 **/
//下载工具类
public class DownloadUtil {
    //下载图书
    public static void downloadIO(String path,String downloadPath){
        FileInputStream fis = null;     //输入
        FileOutputStream fos = null;  //输出
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        try {
            //实现非文本文件的复制
            //1，造文件File
            File srcFile = new File(path);
            File descFile = new File(downloadPath);
            //2，造流
            //2.1 : 造节点流
            fis = new FileInputStream(srcFile);
            fos = new FileOutputStream(descFile);
            //2.2 : 造缓存流（处理流）
            bis = new BufferedInputStream(fis);
            bos = new BufferedOutputStream(fos);

            //3，复制的细节  读取，写入
            byte[] bytes = new byte[1024];
            int len;
            while ((len = bis.read(bytes)) != -1){
                bos.write(bytes,0,len);
            }
            System.out.println("下载成功！！！");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            //资源关闭
            //关闭要求  先关闭内层的流   在关闭外层的流
            //例如：穿衣服  先穿内衣  在穿外衣    脱衣服  先脱外衣   在脱内衣
            if (bos !=null){
                try {
                    bos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (bis !=null){
                try {
                    bis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            //说明：关闭外层流同时，内层流也会自动关闭，关于内层流的关闭，我们可以省略
           /* fos.close();
            fis.close();*/
        }
    }

    //创建一本图书
    public static void uploadIO(String path){
        File file = new File(path);
        try {
            //创建文件
            file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}