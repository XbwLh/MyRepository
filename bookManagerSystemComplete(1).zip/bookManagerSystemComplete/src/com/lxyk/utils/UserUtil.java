package com.lxyk.utils;

import com.lxyk.pojo.User;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName UserUtil
 * @Description TODO
 * @Author FJQ
 * @Date 2022-02-24 19:12
 * @Version 1.0
 **/
public class UserUtil {
    //定义List集合
    private static ArrayList<User> userList = new ArrayList<>();
    //将用户信息存在到list2集合中
    public static List<User> getUserList(){
        BufferedReader br1 = null;
        try {
            br1 = new BufferedReader(new FileReader("admin.txt"));
            String line1;
            while ((line1 = br1.readLine()) != null) {
                String[] split = line1.split(" ");
                userList.add(new User(split[0], split[1], Integer.parseInt(split[2])));
            }

        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if (br1 != null){
                try {
                    br1.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        //返回一个集合
        return userList;
    }

}