package com.lxyk.utils;



//线程类
public class DownloadBook implements Runnable {

    private String path;  //路劲
    private String downloadPath = "C:\\Users\\EDZ\\Desktop\\图书管理系统\\代码\\bookManagerSystemComplete\\library\\";   //下载目录
    private int count;


    public DownloadBook() {
    }

    public DownloadBook(String path,int count) {
        this.path = path;
        this.count = count;
    }

    @Override
    public void run() {
        while (true){
            if (count > 0){
               show();
            }else {
                break;
            }
        }
    }

    private synchronized void show(){
        if (count > 0){
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            String[] split = path.split("\\\\");
            downloadPath += split[split.length-1];
            DownloadUtil.downloadIO(path,downloadPath);
            count --;
        }
    }



}
