package com.lxyk.utils;

import com.lxyk.pojo.Book;
import com.lxyk.pojo.User;
import com.lxyk.service.BookService;
import com.lxyk.service.impl.BookServiceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * @ClassName ScannerUtil
 * @Description TODO
 * @Author FJQ
 * @Date 2022-02-24 19:44
 * @Version 1.0
 **/
public class PrintUtil {

    static Scanner sc = new Scanner(System.in);
    static BookService bs = new BookServiceImpl();

    public static void welcome(){
        System.out.println("*********欢迎来到乐学优课图书管理系统*********");
        System.out.println("系统初始化成功");
        System.out.println("个性化显示菜单");
    }
    public static void exit(){
        System.out.println("*********谢谢使用乐学优课图书管理系统*********");
    }

    public static void showMenu(int level){
        //系统显示(管理员)
        if (level == 1){
            System.out.println("\n操作菜单内容：");
            System.out.println("1.显示所有图书");
            System.out.println("2.整理图书");
            System.out.println("3.查询图书");
            System.out.println("4.添加图书");
            System.out.println("5.修改图书");
            System.out.println("6.下架图书");
            System.out.println("0.退出系统");
        }else {
            //系统显示(普通用户)
            System.out.println("\n操作菜单内容：");
            System.out.println("1.显示所有图书");
            System.out.println("2.查询图书");
            System.out.println("3.借阅图书");
            System.out.println("4.下载电子图书");
            System.out.println("0.退出系统");
        }
    }

    //打印方法
    public static void print(List<Book> list){
        System.out.println(" 图书作者 " + "  图书名称 " + " 图书价格  " + " 图书库存 ");
        //获取集合中的数据
        if (list != null && list.size()>0){
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i)!=null){
                    System.out.println(" " + list.get(i).getAuthor() + "  " + list.get(i).getName() + "  " + list.get(i).getPrice() + " " +list.get(i).getCount());
                }else {
                    System.out.println("    无   " + "    无    " + "   无    " + "   无   ");
                }
            }
        }
    }

    //下载电子图书(使用多线程完成)
    public static void downloadBook() {
        while (true) {
            String name = MyUtil.getInputString("请输入你要下载的图书名称,可以下载一个图书或多个图书,图书之间《英文逗号》隔开", sc);
            String[] split = new String[0];
            int count = 0;
            if (name.length()>0){
                split = name.split(",");
                count++;
            }

            //如果输入一本书，重新把name赋值给split数组
            if (split.length == 0){
                split[0] = name;
            }
            //如果输入多本书，循环下载
            for (String bookName : split) {
                Book book = BookUtil.isExist(bookName);
                if (bookName != null && book.getCount() > 0) {

                    DownloadBook task1 = new DownloadBook(book.getPath(),count);
                    Thread thread = new Thread(task1);
                    thread.start();
                } else {
                    System.out.println("该书名不存在");
                }
            }
            break;
        }
    }

    public static void choice(User user){
        while (true){
            int input = MyUtil.getInput("请输入你的选择", sc);
            switch (input) {
                case 1:
                    //显示所有书籍
                    print( bs.findAllBook());
                    break;
                case 2:
                    case2(user);
                    break;
                case 3:
                    case3(user);
                    break;
                case 4:
                    case4(user);
                    break;
                case 5:
                    case5();
                    break;
                case 6:
                    case6();
                    break;
                case 0:
                    BookUtil.mapIO();
                    exit();
                    System.exit(0);
                default:
                    System.out.println("你输入的数字有误!");
            }
        }
    }

    public static void case2(User user){
        //整理书籍
        if (user.getLevel() == 1){
            BookUtil.sort();
        }else {
            //按照名字查询书籍
            String bookName = MyUtil.getInputString("请输入查询的书籍名称", sc);
            List<Book> list = new ArrayList();
            list.add(bs.findBookByName(bookName));
            print(list);
        }
    }

    public static void case3(User user){
        //按照名字查询书籍
        if (user.getLevel() == 1){
            String bookName = MyUtil.getInputString("请输入查询的书籍名称", sc);
            List<Book> list = new ArrayList();
            list.add(bs.findBookByName(bookName));
            print(list);
        }else {
            //借阅书籍
            String bookName = MyUtil.getInputString("请输入借阅的书籍名称", sc);
            int count = MyUtil.getInput("请输入借阅的书籍数量", sc);
            Book book = BookUtil.isExist(bookName);
            Book tempBook = new Book();
            if (null != book){
                tempBook.setName(bookName);
                tempBook.setCount(book.getCount()-count);
                tempBook.setPrice(book.getPrice());
                bs.borrowBook(tempBook);
                System.out.println("还剩余:" + (book.getCount() + "本"));
            }else {
                System.out.println("该书籍不存在！！！");
            }
        }
    }

    public static void case4(User user){
        //添加书籍
        if (user.getLevel() == 1){
            String book_name = MyUtil.getInputString("请输入你要添加的图书名称", sc);
            //调用方法
            Book book = BookUtil.isExist(book_name);
            //新书添加方法
            if (book == null) {
                //系统中没有该图书
                String book_author = MyUtil.getInputString("请输入图书的作者", sc);
                String book_price = MyUtil.getInputString("请输入图书的价格", sc);
                int book_count = MyUtil.getInput("请输入图书的数量", sc);

                Book tempBook = new Book();
                tempBook.setName("《"+ book_name + "》");
                tempBook.setAuthor(book_author);
                tempBook.setPrice(Double.valueOf(book_price));
                tempBook.setCount(book_count);
                tempBook.setId(BookUtil.getMaxId(BookUtil.getList())+1);
                String path = "C:\\Users\\EDZ\\Desktop\\图书管理系统\\图书馆\\"+book_name+".txt";
                tempBook.setPath(path);
                DownloadUtil.uploadIO(path);
                bs.addBook(tempBook);
                System.out.println("新书添加成功");

            }else {
                           /* int count = MyUtil.getInput("已存在该书,请输入新增图书的数量", sc);
                            book.setCount(book.getCount()+count);
                            String subName = book.getName().substring(1, book.getName().length() - 1);
                            book.setName(subName);
                            bs.borrowBook(book);
                            System.out.println("当前此书籍数量:" + (book.getCount() + "本"));
                            System.out.println("添加成功");*/
                System.out.println("该图书已存在！！！！");
            }
        }else {
            //下载电子书
            downloadBook();
        }
    }

    public static void case5(){
        //修改图书
        String book_name = MyUtil.getInputString("请输入你要修改的图书名称", sc);
        String book_price = MyUtil.getInputString("请输入你要修改的图书的价格", sc);
        int book_count = MyUtil.getInput("请输入你要修改的图书的数量", sc);
        Book tempBook = new Book();
        tempBook.setName(book_name);
        tempBook.setPrice(Double.valueOf(book_price));
        tempBook.setCount(book_count);
        bs.borrowBook(tempBook);
        System.out.println("修改成功");
    }

    public static void case6(){
        //下架图书
        String name = MyUtil.getInputString("请输入你要下架的图书名称", sc);
        bs.removeBook(name);
        System.out.println("下架成功！！！");
    }
}