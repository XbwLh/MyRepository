package com.lxyk.utils;

import java.util.Scanner;

/**
 * @ClassName MyUtil
 * @Description TODO
 * @Author FJQ
 * @Date 2021/10/7 5:52
 * @Version 1.0
 **/
//键盘录入工具类
public class MyUtil {

    /**
     * 得到指定区间的随机数
     */
    public static int getRandom(int min,int max){
        return (int)(Math.random()*(max-min)+min);
    }
    /**
     * 给用户提示的同时，请用户输入一个整数
     */
    public static int getInput(String msg, Scanner sc){
        System.out.println(msg);
        return sc.nextInt();
    }
    /**
     * 给用户提示的同时，请用户输入一个字符串
     */
    public static String getInputString(String msg,Scanner sc){
        System.out.println(msg);
        return sc.next();
    }
}