package com.lxyk.service.impl;

import com.lxyk.dao.BookMapper;
import com.lxyk.dao.impl.BookMapperImpl;
import com.lxyk.pojo.Book;
import com.lxyk.service.BookService;

import javax.naming.Name;
import java.util.List;

/**
 * @ClassName BookServiceImpl
 * @Description TODO
 * @Author FJQ
 * @Date 2022-02-24 21:08
 * @Version 1.0
 **/
public class BookServiceImpl implements BookService {

    BookMapper bookMapper = new BookMapperImpl();

    @Override
    public int addBook(Book book) {
        return bookMapper.insertOne(book);
    }

    @Override
    public int borrowBook(Book book) {
        return bookMapper.updateOne(book);
    }

    //查询
    @Override
    public List<Book> findAllBook() {
        return bookMapper.selectAll();
    }

    @Override
    public Book findBookByName(String name) {
        return bookMapper.selectByName(name);
    }

    @Override
    public int removeBook(String name) {
        return bookMapper.deleteByName(name);
    }
}