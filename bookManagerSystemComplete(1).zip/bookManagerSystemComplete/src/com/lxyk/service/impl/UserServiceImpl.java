package com.lxyk.service.impl;

import com.lxyk.dao.UserMapper;
import com.lxyk.dao.impl.UserMapperImpl;
import com.lxyk.pojo.User;
import com.lxyk.service.UserService;
import com.lxyk.utils.MyUtil;

import java.util.Scanner;

/**
 * @ClassName UserServiceImpl
 * @Description TODO
 * @Author FJQ
 * @Date 2022-02-24 19:09
 * @Version 1.0
 **/
public class UserServiceImpl implements UserService {

    //接口new实现类
    UserMapper userMapper = new UserMapperImpl();
    Scanner sc = new Scanner(System.in);


    //登录(权限校验)
    @Override
    public User login() {
           String username = MyUtil.getInputString("请输入用户名",sc);
           String password = MyUtil.getInputString("请输入密码",sc);
           User user = new User();
           user.setUsername(username);
           user.setPassword(password);
           return userMapper.selectUser(user);
    }
}