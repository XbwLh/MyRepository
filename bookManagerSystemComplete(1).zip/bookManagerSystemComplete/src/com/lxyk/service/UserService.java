package com.lxyk.service;

import com.lxyk.pojo.User;

/**
 * @ClassName UserService
 * @Description TODO
 * @Author EDZ
 * @Date 2022-02-24 19:06
 * @Version 1.0
 **/
public interface UserService {
    //登录(权限校验)
    User login();
}
