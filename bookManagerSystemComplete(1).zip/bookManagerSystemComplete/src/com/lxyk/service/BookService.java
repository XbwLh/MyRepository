package com.lxyk.service;

import com.lxyk.pojo.Book;

import java.util.List;

/**
 * @ClassName BookService
 * @Description TODO
 * @Author EDZ
 * @Date 2022-02-24 19:09
 * @Version 1.0
 **/
public interface BookService {

    //新增图书
    int addBook(Book book);

    //修改图书价格，数量
    int borrowBook(Book book);

    //查询图书
    List<Book> findAllBook();

    //按名字查询图书
    Book findBookByName(String name);

    //下架图书
    int removeBook(String name);
}
