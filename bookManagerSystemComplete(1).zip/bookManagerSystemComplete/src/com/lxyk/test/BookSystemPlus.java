package com.lxyk.test;


import com.lxyk.pojo.User;
import com.lxyk.service.UserService;
import com.lxyk.service.impl.UserServiceImpl;
import com.lxyk.utils.PrintUtil;

/**
 * @ClassName BookSystemPlus
 * @Description TODO
 * @Author FJQ
 * @Date 2022-02-24 19:41
 * @Version 1.0
 **/
public class BookSystemPlus {

    static UserService userService = new UserServiceImpl();
    static User user;

    public static void main(String[] args) {
        //登录
        while (true){
            user = userService.login();
            if (null != user){
                System.out.println("登录成功！");
                break;
            }else {
                System.out.println("登录失败！");
            }
        }

        //进入系统
        PrintUtil.welcome();
        PrintUtil.showMenu(user.getLevel());
        PrintUtil.choice(user);

    }
}