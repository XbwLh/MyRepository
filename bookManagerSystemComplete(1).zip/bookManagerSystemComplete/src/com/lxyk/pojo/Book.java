package com.lxyk.pojo;

import java.util.Objects;

//标准类
public class Book{
    private int id;         //编号
    private String name;    //图书名称
    private String author;  //图书作者
    private double price;   //图书价格
    private String path;    //图书路劲
    private int count;      //图书的库存

    public Book() {
    }

    public Book(int id,  String author,String name, double price,int count) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.price = price;
        this.count = count;
    }

    public Book(int id,  String author,String name, double price, String path,int count) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.price = price;
        this.path = path;
        this.count = count;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", author='" + author + '\'' +
                ", price=" + price +
                ", path='" + path + '\'' +
                ", count=" + count +
                '}';
    }

    public String toString(Book book){
        return
                "" + id +
                " " + author +
                " " + name +
                " " + price +
                " " + path +
                " " + count;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return id == book.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, author, price, path, count);
    }
}
