package com.lxyk.dao.impl;

import com.lxyk.dao.UserMapper;
import com.lxyk.pojo.User;
import com.lxyk.utils.MyUtil;
import com.lxyk.utils.UserUtil;

import java.util.List;
import java.util.Scanner;

/**
 * @ClassName UserMapperImpl
 * @Description TODO
 * @Author FJQ
 * @Date 2022-02-24 19:24
 * @Version 1.0
 **/
public class UserMapperImpl implements UserMapper {

    //定义List集合    通过io流读取   admin.txt  内容，存到userList集合
    private static List<User> userList;

    static {
        userList = UserUtil.getUserList();
    }

    //登录
    @Override
    public User selectUser(User user) {
        for (int i = 0; i < userList.size(); i++) {
            if (user.equals(userList.get(i))){
                return userList.get(i);
            }
        }
        return null;
    }

}