package com.lxyk.dao.impl;

import com.lxyk.dao.BookMapper;
import com.lxyk.pojo.Book;
import com.lxyk.utils.BookUtil;


import java.util.Iterator;
import java.util.List;



/**
 * @ClassName BookMapperImpl
 * @Description TODO
 * @Author FJQ
 * @Date 2022-02-24 20:08
 * @Version 1.0
 **/
public class BookMapperImpl implements BookMapper {

    private static List<Book> bookList;

    static {
        bookList = BookUtil.getList();
    }

    @Override
    public int insertOne(Book book) {
        boolean flag = bookList.add(book);
        if (flag == false){
            return 0;
        }
        return 1;
    }

    @Override
    public int deleteByName(String name) {
        //根据名称返回一个book对象
        Book tempBook = BookUtil.isExist(name);
        if (tempBook != null) {
            Iterator<Book> iterator = bookList.iterator();
            while (iterator.hasNext()){
                Book next = iterator.next();
                if(next.getName().equals("《" + name + "》")){
                    iterator.remove();
                    return 1;
                }
            }
        }else {
            System.out.println("该图书不存在!");
        }
        //删除失败，返回0
        return 0;
    }


    @Override
    public int updateOne(Book book) {
        //根据名称返回一个book对象
        Book tempBook = BookUtil.isExist(book.getName());
        if (tempBook != null){
            tempBook.setPrice(book.getPrice());
            tempBook.setCount(book.getCount());
            //修改成功  返回1
            return 1;
        }else {
            System.out.println("该书名不存在!");
            //修改失败  返回0
            return 0;
        }
    }

    //查询
    @Override
    public List<Book> selectAll() {
        return bookList;
    }

    @Override
    public Book selectByName(String name) {
        Book book = BookUtil.isExist(name);
        return book;
    }
}