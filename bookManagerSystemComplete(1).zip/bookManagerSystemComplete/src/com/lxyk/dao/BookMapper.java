package com.lxyk.dao;

import com.lxyk.pojo.Book;

import java.util.List;

/**
 * @ClassName BookMapper
 * @Description TODO
 * @Author EDZ
 * @Date 2022-02-24 19:57
 * @Version 1.0
 **/
public interface BookMapper {
    //新增
    int insertOne(Book book);
    //删除
    int deleteByName(String name);
    //修改
    int updateOne(Book book);
    //查询
    List<Book> selectAll();
    //根据名称查询
    Book selectByName(String name);
}
