package com.lxyk.dao;

import com.lxyk.pojo.User;

/**
 * @ClassName UserMapper
 * @Description TODO
 * @Author EDZ
 * @Date 2022-02-24 19:20
 * @Version 1.0
 **/
public interface UserMapper {

    //登录
    User selectUser(User user);
}
